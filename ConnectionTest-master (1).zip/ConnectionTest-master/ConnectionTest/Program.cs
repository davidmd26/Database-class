﻿using System;
using System.Data.SqlClient;
using NLog;

namespace ConnectionTest
{
	class Program
	{

		private static Logger logger = LogManager.GetCurrentClassLogger();

		static void Main(string[] args)
		{
			logger.Info("Testing Connection");
			TestConnection();
			try
			{
				logger.Debug("Getting Top 10 from feds1");
				string sql = "SELECT TOP 10 * from feds1";
				using SqlConnection conn = GetConnection();
				conn.Open();
				using SqlCommand cmd = new SqlCommand(sql, conn);
				using SqlDataReader sdr = cmd.ExecuteReader();
				if (sdr.HasRows)
				{
					while (sdr.Read())
					{
						logger.Debug($"Adshex: {sdr.GetString(sdr.GetOrdinal("Adshex"))}");
					}
				}
			}
			catch (Exception e)
			{
				logger.Error(e.StackTrace);
			}
			logger.Info("Completed Successfully");
		}

		private static bool TestConnection()
		{
			try
			{
				using SqlConnection conn = GetConnection();
				conn.Open();
				logger.Debug("Connected");
			}
			catch(Exception e)
            {
				logger.Error($"Not Connected {e.StackTrace}");
				return false;
			}
			return true;
		}

		private static SqlConnection GetConnection()
		{
			string _connstr = "Server=DESKTOP-IFN84LU\\SQLEXPRESS;Database=EET4250;Trusted_Connection=True;MultipleActiveResultSets=true;Connection Timeout=60";
			SqlConnection Connection = null;
			try
			{
				Connection = new SqlConnection(_connstr);
			}
			catch (Exception e)
			{
				logger.Error(e.StackTrace);
			}
			return Connection;
		}
	}
}
